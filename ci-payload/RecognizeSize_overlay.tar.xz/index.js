
import {AppRegistry, Image} from 'react-native';
import {PluginManager} from 'sn-plugin-lib';
import App from './App';
import {name as appName} from './app.json';
import {recordPress} from './src/platform/events';
import './src/i18n';
import en from './src/i18n/en.json';
import it from './src/i18n/it.json';
export const SETTINGS_BUTTON = 100;
export const CONVERT_BUTTON = 200;
async function boot() {
  AppRegistry.registerComponent(appName, () => App);
  PluginManager.init();
  PluginManager.registerButtonListener({
    onButtonPress: event => {
      const raw = event && (event.id ?? event.button?.id);
      const id = typeof raw === 'string' ? Number(raw) : raw;
      if (id === SETTINGS_BUTTON || id === CONVERT_BUTTON) recordPress(id);
    },
  });
  const icon = Image.resolveAssetSource(require('./assets/icon.png'))?.uri;
  await PluginManager.registerButton(1, ['NOTE'], {
    id: SETTINGS_BUTTON,
    name: JSON.stringify({en: en.menuSettings, zh_CN: en.menuSettings, zh_TW: en.menuSettings, ja: en.menuSettings, it: it.menuSettings}),
    ...(icon ? {icon} : {}),
    showType: 1,
  });
  await PluginManager.registerButton(2, ['NOTE'], {
    id: CONVERT_BUTTON,
    name: JSON.stringify({en: en.menuConvert, zh_CN: en.menuConvert, zh_TW: en.menuConvert, ja: en.menuConvert, it: it.menuConvert}),
    ...(icon ? {icon} : {}),
    editDataTypes: [0],
    showType: 1,
  });
}
boot().catch(e => console.warn(`[RecognizeSize] boot: ${String(e)}`));
