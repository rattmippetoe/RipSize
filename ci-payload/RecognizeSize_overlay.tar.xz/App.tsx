
import React, {useEffect, useRef, useState} from 'react';
import {Pressable, StyleSheet, Text, TextInput, View} from 'react-native';
import RNFS from 'react-native-fs';
import {PluginManager, PluginCommAPI, PluginFileAPI, PluginNoteAPI} from 'sn-plugin-lib';
import {useTranslation} from 'react-i18next';
import './src/i18n';
import {observePresses} from './src/platform/events';
import {currentDeviceType} from './src/platform/device';
import {loadSize, saveSize, getPrivateDir} from './src/platform/settings';
import {ensureNotePermissions} from './src/platform/permissions';
import {normalizeFontSize} from './src/core/config';
import {convertSelection} from './src/core/convert';
type Mode = 'settings' | 'working' | 'error';
const SETTINGS_BUTTON = 100;
const CONVERT_BUTTON = 200;
function TapButton({label, onPress, primary = false}: {
  label: string;
  onPress: () => void;
  primary?: boolean;
}): React.JSX.Element {
  return <Pressable onPress={onPress} style={[styles.button, primary && styles.primary]}>
    <Text style={[styles.buttonText, primary && styles.primaryText]}>{label}</Text>
  </Pressable>;
}
function App(): React.JSX.Element {
  const {t} = useTranslation();
  const [mode, setMode] = useState<Mode>('settings');
  const [deviceType, setDeviceType] = useState(-1);
  const [privateDir, setPrivateDir] = useState('');
  const [sizeInput, setSizeInput] = useState('36');
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);
  const busy = useRef(false);
  const alive = useRef(true);
  
  const openSettings = async () => {
    try {
      const type = await currentDeviceType(PluginManager);
      const directory = await getPrivateDir(PluginManager);
      const fontSize = await loadSize(RNFS, directory, type);
      if (!alive.current) return;
      setDeviceType(type);
      setPrivateDir(directory);
      setSizeInput(String(fontSize));
      setMode('settings');
      setMessage('');
    } catch (error) {
      if (alive.current) {
        setMode('error');
        setMessage(String((error as Error).message || error));
      }
    }
  };
  
  const recognizeNow = async () => {
    if (busy.current) return;
    busy.current = true;
    setMode('working');
    setMessage('');
    try {
      const type = await currentDeviceType(PluginManager);
      const directory = await getPrivateDir(PluginManager);
      const fontSize = await loadSize(RNFS, directory, type);
      await ensureNotePermissions(PluginManager, t('permissionReason'));
      const result = await convertSelection({
        comm: PluginCommAPI,
        file: PluginFileAPI,
        note: PluginNoteAPI,
      }, fontSize);
      if (!alive.current) return;
      if (result.status === 'success') {
        PluginManager.closePluginView();
      } else {
        setMode('error');
        setMessage(t(result.status, {defaultValue:result.warning || t('error')}));
      }
    } catch (error) {
      if (alive.current) {
        setMode('error');
        setMessage(String((error as Error).message || error));
      }
    } finally {
      busy.current = false;
    }
  };
  useEffect(() => {
    alive.current = true;
    const unsubscribe = observePresses(id => {
      if (id === CONVERT_BUTTON) { void recognizeNow(); }
      if (id === SETTINGS_BUTTON) { void openSettings(); }
    });
    return () => { alive.current = false; unsubscribe(); };
  }, []);
  
  const persist = async () => {
    const n = Number(sizeInput);
    if (!sizeInput.trim() || normalizeFontSize(n) === null) {
      setMessage(t('invalid'));
      return;
    }
    setSaving(true);
    setMessage('');
    try {
      await saveSize(RNFS, privateDir, deviceType, n);
      PluginManager.closePluginView();
    } catch (error) {
      setMessage(String((error as Error).message || error));
    } finally { setSaving(false); }
  };
  
  const step = (delta: number) => {
    const current = Number(sizeInput);
    const next = Math.max(1, Math.min(50, (Number.isInteger(current) ? current : 36) + delta));
    setSizeInput(String(next));
  };
  return <View style={styles.screen}>
    <Text style={styles.heading}>{t('name')}</Text>
    {mode === 'settings' ? <>
      <Text style={styles.explanation}>{t('description')}</Text>
      <Text style={styles.label}>{t('sizeLabel')}</Text>
      <View style={styles.inputRow}>
        <TapButton label="−" onPress={() => step(-1)} />
        <TextInput
          style={styles.numericInput}
          keyboardType="number-pad"
          selectTextOnFocus
          value={sizeInput}
          onChangeText={setSizeInput}
          maxLength={2}
          accessibilityLabel={t('sizeLabel')}
        />
        <TapButton label="+" onPress={() => step(1)} />
      </View>
      <Text style={styles.hint}>{t('range')}</Text>
      <Text style={styles.hint}>{t('defaultHint')}</Text>
      {message ? <Text style={styles.warning}>{message}</Text> : null}
      <View style={styles.footer}>
        <TapButton label={saving ? t('saving') : t('save')} primary onPress={() => { if (!saving) void persist(); }} />
        <TapButton label={t('close')} onPress={() => PluginManager.closePluginView()} />
      </View>
    </> : <>
      <Text style={styles.explanation}>{mode === 'working' ? t('recognizing') : t('error')}</Text>
      {mode === 'error' ? <>
        <Text style={styles.warning}>{message}</Text>
        <Text style={styles.hint}>{t('errorHint')}</Text>
        <TapButton label={t('close')} primary onPress={() => PluginManager.closePluginView()} />
      </> : null}
    </>}
  </View>;
}
const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor:'#ffffff', padding:24},
  heading: {fontSize:26, color:'#000000', fontWeight:'700', marginBottom:24},
  explanation: {fontSize:19, color:'#000000', marginBottom:24},
  label: {fontSize:20, fontWeight:'700', color:'#000000', marginBottom:12},
  inputRow: {flexDirection:'row', alignItems:'center', gap:14, marginBottom:16},
  numericInput: {fontSize:32, color:'#000000', borderWidth:2, borderColor:'#000000', paddingHorizontal:12, minWidth:86, textAlign:'center', height:62},
  button: {minHeight:54, minWidth:58, justifyContent:'center', alignItems:'center', backgroundColor:'#ffffff', borderWidth:2, borderColor:'#000000', paddingVertical:10, paddingHorizontal:16, marginRight:10},
  primary: {backgroundColor:'#000000'},
  buttonText: {fontSize:20, color:'#000000', fontWeight:'600'},
  primaryText: {color:'#ffffff'},
  hint: {fontSize:16, color:'#333333', marginTop:12},
  warning: {fontSize:18, color:'#000000', fontWeight:'700', marginTop:20},
  footer: {flexDirection:'row', flexWrap:'wrap', marginTop:30, gap:10},
});
export default App;
