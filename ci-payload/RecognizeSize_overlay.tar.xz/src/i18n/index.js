
import i18n from 'i18next';
import {initReactI18next} from 'react-i18next';
import en from './en.json';
import it from './it.json';
if (!i18n.isInitialized) {
  i18n.use(initReactI18next).init({
    resources: {en: {translation: en}, it: {translation: it}},
    lng: 'en', fallbackLng: 'en', compatibilityJSON: 'v4',
    interpolation: {escapeValue: false},
  });
}
export default i18n;
