
'use strict';
const READ = 'plugin.permission.FILE:READ';
const WRITE = 'plugin.permission.FILE:WRITE';
async function ensureNotePermissions(manager, description) {
  for (const permission of [READ, WRITE]) {
    const status = await manager.hasPermission(permission);
    if (status === 1) continue;
    const granted = await manager.requestPermission(permission, description);
    if (granted !== 1 && granted !== 2) {
      throw new Error('Note file access was not granted');
    }
  }
}
module.exports = {READ, WRITE, ensureNotePermissions};
