
'use strict';
const {defaultFontSize, normalizeFontSize, settingsFilename} = require('../core/config');
function settingsPath(pluginDir, deviceType) {
  if (typeof pluginDir !== 'string' || !pluginDir.trim()) {
    throw new Error('Plugin private directory is unavailable');
  }
  return `${pluginDir}/settings/${settingsFilename(deviceType)}`;
}
async function getPrivateDir(manager) {
  const response = await manager.getPluginDirPath();
  const result = response && typeof response === 'object' && 'result' in response ? response.result : response;
  if (typeof result !== 'string' || !result.trim()) throw new Error('Private plugin storage unavailable');
  return result;
}
async function loadSize(fs, pluginDir, deviceType) {
  const fallback = defaultFontSize(deviceType);
  try {
    const path = settingsPath(pluginDir, deviceType);
    if (!(await fs.exists(path))) return fallback;
    const parsed = JSON.parse(await fs.readFile(path, 'utf8'));
    return normalizeFontSize(parsed.fontSize) ?? fallback;
  } catch (_) {
    return fallback;
  }
}
async function saveSize(fs, pluginDir, deviceType, size) {
  const valid = normalizeFontSize(size);
  if (valid === null) throw new Error('Invalid font size');
  const path = settingsPath(pluginDir, deviceType);
  await fs.mkdir(path.substring(0, path.lastIndexOf('/')));
  await fs.writeFile(path, JSON.stringify({version:1, fontSize:valid}, null, 2), 'utf8');
}
module.exports = {settingsPath, getPrivateDir, loadSize, saveSize};
