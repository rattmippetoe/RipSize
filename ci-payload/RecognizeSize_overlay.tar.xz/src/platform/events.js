
'use strict';
let queuedButton = null;
let receiver = null;
function recordPress(id) {
  queuedButton = id;
  if (receiver) {
    const callback = receiver;
    queuedButton = null;
    callback(id);
  }
}
function observePresses(callback) {
  receiver = callback;
  if (queuedButton !== null) {
    const id = queuedButton;
    queuedButton = null;
    callback(id);
  }
  return () => { if (receiver === callback) receiver = null; };
}
module.exports = {recordPress, observePresses};
