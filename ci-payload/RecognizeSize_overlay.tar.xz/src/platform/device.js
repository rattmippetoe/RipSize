
'use strict';
async function currentDeviceType(manager) {
  try {
    const result = await manager.getDeviceType();
    const raw = result && typeof result === 'object' && 'result' in result
      ? result.result : result;
    return Number.isInteger(raw) ? raw : -1;
  } catch (_) {
    return -1;
  }
}
module.exports = {currentDeviceType};
