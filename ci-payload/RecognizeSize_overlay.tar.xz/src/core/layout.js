
'use strict';
function validRect(rect) {
  return !!rect && ['left','top','right','bottom'].every(k=>Number.isFinite(rect[k])) &&
    rect.right > rect.left && rect.bottom > rect.top;
}
function planTextRect(lassoRect, pageSize, recognized, fontSize) {
  if (!validRect(lassoRect) || !pageSize ||
      !Number.isFinite(pageSize.width) || !Number.isFinite(pageSize.height)) {
    throw new Error('Invalid lasso or page geometry');
  }
  const lines = recognized.split(/\r?\n/);
  const maxChars = Math.max(1, ...lines.map(line=>line.length));
  const left = Math.max(0, Math.min(pageSize.width - 2, Math.floor(lassoRect.left)));
  const top = Math.max(0, Math.min(pageSize.height - 2, Math.floor(lassoRect.top)));
  const wantedW = Math.max(lassoRect.right - lassoRect.left, Math.ceil(maxChars * fontSize * 0.57 + fontSize));
  const wantedH = Math.max(lassoRect.bottom - lassoRect.top, Math.ceil(lines.length * fontSize * 1.5));
  return {
    left, top,
    right: Math.min(pageSize.width, Math.max(left + 1, left + wantedW)),
    bottom: Math.min(pageSize.height, Math.max(top + 1, top + wantedH)),
  };
}
function extractRect(value) {
  const raw = value && value.rect ? value.rect : value;
  return validRect(raw) ? raw : null;
}
module.exports = {validRect, planTextRect, extractRect};
