
'use strict';
const NOMAD = 4;
const MANTA = 5;
const MIN_FONT_SIZE = 1;
const MAX_FONT_SIZE = 50;
function defaultFontSize(deviceType) {
  return deviceType === NOMAD ? 26 : 36;
}
function normalizeFontSize(candidate) {
  if (typeof candidate !== 'number' ||
      !Number.isInteger(candidate) ||
      candidate < MIN_FONT_SIZE || candidate > MAX_FONT_SIZE) {
    return null;
  }
  return candidate;
}
function settingsFilename(deviceType) {
  return `RecognizeSize-device-${Number.isInteger(deviceType) ? deviceType : 'unknown'}.json`;
}
module.exports = {
  NOMAD, MANTA, MIN_FONT_SIZE, MAX_FONT_SIZE,
  defaultFontSize, normalizeFontSize, settingsFilename,
};
