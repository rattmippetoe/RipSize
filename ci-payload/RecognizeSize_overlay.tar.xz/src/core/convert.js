
'use strict';
const {planTextRect, extractRect} = require('./layout');
const {normalizeFontSize} = require('./config');
function unwrap(response, action) {
  if (!response || response.success !== true) {
    const detail = response && response.error && response.error.message;
    throw new Error(`${action}: ${detail || 'device rejected operation'}`);
  }
  return response.result;
}
function snapshot(element) {
  return JSON.parse(JSON.stringify(element));
}
function isIndexedStroke(item) {
  return item && item.type === 0 && Number.isInteger(item.numInPage) && item.numInPage >= 0;
}
function savedTextMatches(elements, text, fontSize) {
  return elements.some(element => {
    const m = snapshot(element);
    const b = m && m.textBox;
    return m.type === 500 && b && b.textContentFull === text && Number(b.fontSize) === fontSize;
  });
}
async function readSavedElements(file, path, page) {
  const result = unwrap(await file.getElements(page, path), 'getElements');
  if (!Array.isArray(result)) throw new Error('getElements returned a non-array');
  return result;
}
function recycleAll(elements) {
  for (const el of elements) {
    try { if (typeof el?.recycle === 'function') el.recycle(); } catch (_) {  }
  }
}
function selectedStrokesStillPresent(saved, selected) {
  const byNum = new Map(saved.map(el => {
    const m = snapshot(el);
    return [m.numInPage, m];
  }));
  return selected.every(old => {
    const current = byNum.get(old.numInPage);
    if (!current || current.type !== 0) return false;
    if (old.uuid != null && current.uuid != null && old.uuid !== current.uuid) return false;
    return true;
  });
}
async function convertSelection(sdk, desiredSize, options = {}) {
  const size = normalizeFontSize(desiredSize);
  if (size === null) throw new Error('Font size must be a whole number from 1 to 50');
  const {comm, file, note} = sdk;
  let lassoElements = [];
  let savedElements = [];
  let lassoReleased = false;
  try {
    const [countResponse, elResponse, rectResponse, pathResponse, pageResponse] = await Promise.all([
      comm.getLassoElementTypeCounts(),
      comm.getLassoElements(),
      comm.getLassoRect(),
      comm.getCurrentFilePath(),
      comm.getCurrentPageNum(),
    ]);
    const counts = unwrap(countResponse, 'getLassoElementTypeCounts') || {};
    lassoElements = unwrap(elResponse, 'getLassoElements');
    const lassoRect = extractRect(unwrap(rectResponse, 'getLassoRect'));
    const path = unwrap(pathResponse, 'getCurrentFilePath');
    const page = unwrap(pageResponse, 'getCurrentPageNum');
    if (!lassoRect || !Array.isArray(lassoElements) || !lassoElements.length) {
      return {status:'no-selection'};
    }
    const selected = lassoElements.map(snapshot);
    if (!selected.every(isIndexedStroke)) {
      return {status:'unsupported-selection',warning:'Selection contains non-plain strokes; kept unchanged.'};
    }
    if ((counts.trailNum || 0) + (counts.trailLinkNum || 0) + (counts.titleNum || 0) === 0) {
      return {status:'no-selection'};
    }
    const pageSize = unwrap(await file.getPageSize(path, page), 'getPageSize');
    const recognized = unwrap(await comm.recognizeElements(lassoElements, pageSize), 'recognizeElements');
    if (typeof recognized !== 'string' || !recognized.trim()) {
      return {status:'recognition-empty'};
    }
    const text = recognized.trim();
    const target = planTextRect(lassoRect, pageSize, text, size);
    unwrap(await comm.setLassoBoxState(2), 'setLassoBoxState');
    lassoReleased = true;
    unwrap(await note.insertText({textContentFull:text, textRect:target, fontSize:size}), 'insertText');
    unwrap(await note.saveCurrentNote(), 'saveCurrentNote');
    savedElements = await readSavedElements(file, path, page);
    const confirmed = savedTextMatches(savedElements, text, size);
    if (!confirmed) {
      return {status:'insert-unverified',text,inkRemoved:false,warning:'Text insert could not be verified. Original handwriting was not deleted.'};
    }
    if (options.preserveInk) {
      return {status:'success-preview',text,inkRemoved:false};
    }
    if (!selectedStrokesStillPresent(savedElements, selected)) {
      return {status:'ink-unverified',text,inkRemoved:false,warning:'Original stroke IDs changed. Handwriting was not deleted.'};
    }
    const nums = selected.map(m => m.numInPage);
    const deleted = unwrap(await file.deleteElements(path, page, nums), 'deleteElements');
    if (deleted === false) throw new Error('deleteElements returned false; source ink may remain');
    unwrap(await comm.reloadFile(), 'reloadFile');
    return {status:'success',text,inkRemoved:true};
  } finally {
    recycleAll(lassoElements);
    recycleAll(savedElements);
    if (!lassoReleased) {
      try { await comm.setLassoBoxState(2); } catch (_) {  }
    }
  }
}
module.exports = {
  unwrap, snapshot, isIndexedStroke, savedTextMatches,
  selectedStrokesStillPresent, convertSelection,
};
